"""
Custom user model and manager using email as the username.
"""

from django.contrib.auth.base_user import AbstractBaseUser, BaseUserManager
from django.contrib.auth.models import PermissionsMixin
from django.db import models
from django.utils import translation


class UserManager(BaseUserManager):
    """
    Custom manager for the User model.

    Provides factory methods to create regular users and superusers while
    ensuring email normalization and secure password hashing.
    """
    def create_user(self, email, password=None, **extra):
        """
        Create and save a regular user with the given email and password.

        Args:
            email (str): The user's email address (required; used as username).
            password (str | None): The user's raw password. If None, the user
                will need to set a password later.
            **extra: Additional fields to set on the user instance.

        Returns:
            User: The created user instance.
        """
        if not email:
            raise ValueError(translation.gettext("Email required"))
        email = self.normalize_email(email)
        user = self.model(email=email, **extra)
        user.set_password(password)
        user.save()
        return user

    def create_superuser(self, email, password=None, **extra):
        """
        Create and save a superuser with the given email and password.

        Args:
            email (str): The superuser's email address.
            password (str | None): The raw password.
            **extra: Additional fields to set on the user instance.

        Returns:
            User: The created superuser instance.
        """
        extra.setdefault("is_staff", True)
        extra.setdefault("is_superuser", True)
        return self.create_user(email, password, **extra)


class User(AbstractBaseUser, PermissionsMixin):
    """
    Application's custom user model using email as the username field.
    """
    # Override PermissionsMixin relations to avoid reverse accessor clashes
    groups = models.ManyToManyField(
        "auth.Group",
        blank=True,
        help_text="The groups this user belongs to.",
        related_name="profiles_user_set",
        related_query_name="profiles_user",
        verbose_name="groups",
    )
    user_permissions = models.ManyToManyField(
        "auth.Permission",
        blank=True,
        help_text="Specific permissions for this user.",
        related_name="profiles_user_set_permissions",
        related_query_name="profiles_user_permission",
        verbose_name="user permissions",
    )
    email = models.EmailField(unique=True)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS: list[str] = []

    objects = UserManager()
