// Global test setup for Vitest
import "@testing-library/jest-dom";
