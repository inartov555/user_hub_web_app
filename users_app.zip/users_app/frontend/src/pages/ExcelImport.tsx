import React, { useState, useRef } from "react";
import { useTranslation } from "react-i18next";
import { api } from "../lib/axios";
import { extractApiError } from "../lib/httpErrors";
import { useAuthStore } from "../auth/store";
import { Input } from "../components/input";

export default function ExcelImportPanel() {
  const { t } = useTranslation();
  const [file, setFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [summary, setSummary] = useState<null | {
    created: number;
    updated: number;
    processed: number;
    errors: { row: number; msg: string }[];
  }>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [inputKey, setInputKey] = useState(0);
  const { accessToken } = useAuthStore();
  const [error, setError] = useState<string | null>(null);

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setMessage(null);
    setSummary(null);
    const input = e.currentTarget;
    const a_file = input.files?.[0] || null;
    console.log('picked:', a_file?.name);
    setFile(a_file);
  };

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setMessage(null);
    setSummary(null);

    try {
      const form = new FormData();
      form.append("file", file);

      const resp = await api.post(`/import-excel/`, form, {
        headers: accessToken ? { Authorization: `Bearer ${accessToken}`, "Content-Type": `multipart/form-data` } : undefined,
        // onUploadProgress: (e) => { /* optional progress */ },
      });

      const payload = resp?.data;
      setSummary(payload?.result ?? payload);
      setMessage(t("excelImport.importSuccessful"));

      // Reset the input for the *next* upload (without interfering with current display)
      setFile(null);
      setInputKey((k) => k + 1);
    } catch (err: any) {
      const parsed = extractApiError(err as unknown);
      setError(`${t("excelImport.excelImportFailure")} ${parsed.message}`);
    } finally {
      setSubmitting(false);
    }
  }

  async function downloadTemplate(e: React.MouseEvent<HTMLButtonElement>) {
    e.preventDefault();
    try {
      const resp = await api.get(`/import-excel/`, {
        headers: accessToken ? { Authorization: `Bearer ${accessToken}`, "Content-Type": `multipart/form-data` } : undefined,
        responseType: "blob",
      });
      const fileBlob = new Blob([resp.data]);
      const url = window.URL.createObjectURL(fileBlob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "import_template.xlsx";
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      const parsed = extractApiError(err as unknown);
      setError(`${t("excelImport.templateDownloadFailed")} ${parsed.message}`);
    }
  }

  return (
    <div className="max-w-xl mx-auto p-4 rounded-2xl shadow bg-white border dark:bg-slate-800 dark:text-slate-100 dark:border-slate-700">
      <h2 className="text-xl font-semibold mb-3">{t("excelImport.title")}</h2>
      <p className="text-sm text-gray-600 mb-4">{t("excelImport.fileUploadMessage")} <code>{t("signup.email")}</code>, <code>{t("signup.username")}</code>, <code>{t("users.firstName")}</code>, <code>{t("users.lastName")}</code>, <code>{t("excelImport.bio")}</code>.</p>

      <form onSubmit={onSubmit} className="space-y-3">
        <Input
          key={inputKey}
          ref={inputRef}
          type="file"
          name="file"
          accept=".xlsx,.xls,.csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel,text/csv"
          onChange={onFileChange}
          onClick={(e) => { (e.currentTarget as HTMLInputElement).value = ""; }} // allow re-select same file
        />
        {file && (
          <div className="text-sm text-gray-600 dark:text-slate-300 mt-1">{t("excelImport.selectedFile")} {file.name}</div>
        )}

        {error && <p className="text-red-600 text-sm whitespace-pre-line">{error}</p>}
        <div className="flex gap-2">
          <button id="importTemplate" className="px-4 py-2 rounded-xl bg-brand-600 text-white hover:bg-brand-700
              focus:outline-none focus:ring-2 focus:ring-brand-500
              disabled:opacity-50 disabled:cursor-not-allowed" type="submit" disabled={!file || submitting}>
            {submitting ? t("excelImport.uploading") : t("excelImport.startImport")}
          </button>

          {/* If you rely on cookie auth, a plain anchor works: href={`${api.defaults.baseURL}/import-excel/`} */}
          {accessToken ? (
            <button id="downloadTemplate" className="px-4 py-2 rounded-xl border text-slate-700 bg-white
              hover:bg-slate-50
              dark:text-slate-100 dark:bg-slate-800 dark:border-slate-600
              dark:hover:bg-slate-700" onClick={downloadTemplate}>
              {t("excelImport.downloadTemplate")}
            </button>
          ) : (
            <a className="btn btn-ghost px-4 py-2 rounded-xl border" href={`${api.defaults.baseURL}/import-excel/`} download>
              {t("excelImport.downloadTemplate")}
            </a>
          )}
        </div>
      </form>

      {message && (
        <div className="mt-4 text-sm p-2 rounded-xl border bg-gray-50 dark:bg-slate-800 dark:text-slate-100 dark:border-slate-700">{message}</div>
      )}

      {summary && (
        <div className="mt-4 p-3 rounded-2xl border bg-white
                dark:bg-slate-800 dark:border-slate-700">
          <div data-tag="resultSuccessTitle" className="font-medium mb-2">{t("excelImport.result")}</div>
          <ul data-tag="resultSuccessBody" className="text-sm space-y-1">
            <li>{t("excelImport.processed")} <span className="font-semibold">{summary.processed}</span></li>
            <li>{t("excelImport.created")} <span className="font-semibold">{summary.created}</span></li>
            <li>{t("excelImport.updated")} <span className="font-semibold">{summary.updated}</span></li>
          </ul>

          {summary.errors?.length ? (
            <div className="mt-3">
              <div className="font-medium mb-1">Errors ({summary.errors.length})</div>
              <div className="max-h-48 overflow-auto border rounded-xl">
                <table className="w-full text-sm">
                  <thead className="sticky top-0 bg-white dark:bg-slate-900">
                    <tr>
                      <th className="text-left p-2 border-b w-24">Row</th>
                      <th className="text-left p-2 border-b">Message</th>
                    </tr>
                  </thead>
                  <tbody>
                    {summary.errors.map((e, idx) => (
                      <tr key={idx} className="odd:bg-gray-50 dark:odd:bg-slate-800">
                        <td className="p-2 border-b">{e.row}</td>
                        <td className="p-2 border-b">{e.msg}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : null}
        </div>
      )}
    </div>
  );
}
